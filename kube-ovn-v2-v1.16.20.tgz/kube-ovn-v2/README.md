# Helm chart for Kube-OVN

![Version: v1.16.20](https://img.shields.io/badge/Version-v1.16.20-informational?style=flat-square)

This is the v2 of the Helm Chart, replacing the first version in the long term.
Make sure to adjust your old values with the new ones and pre-generate your templates with a dry-run to ensure no breaking change occurs.

## Installing the Chart

### From OCI Registry

The Helm chart is available from GitHub Container Registry:

```bash
helm install kube-ovn oci://ghcr.io/kubeovn/charts/kube-ovn-v2 --version v1.16.20
```

### From Source

```bash
helm install kube-ovn ./charts/kube-ovn-v2
```

## How to install Kube-OVN on Talos Linux

To install Kube-OVN on Talos Linux, declare the **OpenvSwitch** module in the `machine` config of your Talos install:

```yaml
machine:
  kernel:
    modules:
    - name: openvswitch
```

Then use the following options to install this chart:

```yaml
ovsOvn:
  disableModulesManagement: true
  ovsDirectory: "/var/lib/openvswitch"
  ovnDirectory: "/var/lib/ovn"
  ovsIpsecKeysDirectory: "/var/lib/ovs_ipsec_keys"
cni:
  mountToolingDirectory: false
```

All three `ovsOvn` directories must point outside `/etc`, which is read-only on Talos. `ovsIpsecKeysDirectory`
only becomes a host mount when `features.enableOvnIpsec` is enabled, but setting it up front keeps IPSEC
from failing later with `mkdir /etc/origin: read-only file system`.

## Externally managed webhook certificates

By default, enabling the validating webhook creates a cert-manager Certificate and
a self-signed Issuer. To use your own Certificate specification and existing
Issuer or ClusterIssuer, keep the webhook enabled and disable only certificate
creation:

```yaml
validatingWebhook:
  enabled: true
  certificate:
    create: false
```

Manage the replacement Certificate outside this chart, for example in a parent
chart. It must be named `kube-ovn-webhook-serving-cert` in the configured
`namespace` and write to `kube-ovn-webhook-secret`. Include all three Service DNS
names, substituting your configured `namespace` and `clusterDomain`:

```yaml
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: kube-ovn-webhook-serving-cert
  namespace: kube-system
spec:
  secretName: kube-ovn-webhook-secret
  dnsNames:
    - kube-ovn-webhook.kube-system
    - kube-ovn-webhook.kube-system.svc
    - kube-ovn-webhook.kube-system.svc.cluster.local
  issuerRef:
    group: cert-manager.io
    kind: Issuer
    name: existing-webhook-issuer
```

The referenced Issuer must already exist in the Certificate namespace, or use
`kind: ClusterIssuer` for a cluster-scoped issuer. Add any certificate policy
fields required by your environment to this external Certificate.

The webhook requires `tls.crt` and `tls.key` in `kube-ovn-webhook-secret`
to serve HTTPS. The serving process does not require `ca.crt`.

cert-manager's CA injector uses the webhook's `cert-manager.io/inject-ca-from`
annotation to locate the Certificate named `kube-ovn-webhook-serving-cert`.
It copies `ca.crt` from that Certificate's backing Secret into the webhook's
`caBundle`, which the API server uses to verify the webhook's serving certificate.

For an existing installation, plan the Certificate ownership transfer before
changing this setting. Helm removes the previously managed Certificate and Issuer
on upgrade; simply applying another Certificate with the same name does not
transfer ownership. Secret deletion also depends on cert-manager owner-reference
configuration.

## How to regenerate this README

This README is generated using [helm-docs](https://github.com/norwoodj/helm-docs). Launch `helm-docs` while in this folder to regenerate the documented values.

## Values

<h3>ACL sampling configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>aclSampling</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Experimental OVN ACL sampling for NetworkPolicy events.</td>
		</tr>
		<tr>
			<td>aclSampling.allowProbabilityPercent</td>
			<td>float</td>
			<td><pre lang="json">
1
</pre>
</td>
			<td>Sampling probability percentage for allowed decisions. Fractional percentages are supported.</td>
		</tr>
		<tr>
			<td>aclSampling.appIDEstablished</td>
			<td>int</td>
			<td><pre lang="json">
103
</pre>
</td>
			<td>OVN sampling application ID for established ACL sessions.</td>
		</tr>
		<tr>
			<td>aclSampling.appIDNew</td>
			<td>int</td>
			<td><pre lang="json">
102
</pre>
</td>
			<td>OVN sampling application ID for new ACL sessions.</td>
		</tr>
		<tr>
			<td>aclSampling.collectorIDAllow</td>
			<td>int</td>
			<td><pre lang="json">
1
</pre>
</td>
			<td>OVN sample collector ID for allowed decisions.</td>
		</tr>
		<tr>
			<td>aclSampling.collectorIDDefaultDeny</td>
			<td>int</td>
			<td><pre lang="json">
2
</pre>
</td>
			<td>OVN sample collector ID for default-deny decisions.</td>
		</tr>
		<tr>
			<td>aclSampling.defaultDenyProbabilityPercent</td>
			<td>float</td>
			<td><pre lang="json">
100
</pre>
</td>
			<td>Sampling probability percentage for default-deny decisions. Fractional percentages are supported.</td>
		</tr>
		<tr>
			<td>aclSampling.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable controller-side ACL sampling and node-local psample delivery.</td>
		</tr>
		<tr>
			<td>aclSampling.localGroupID</td>
			<td>int</td>
			<td><pre lang="json">
142
</pre>
</td>
			<td>Linux psample multicast group ID used for local delivery.</td>
		</tr>
		<tr>
			<td>aclSampling.setID</td>
			<td>int</td>
			<td><pre lang="json">
142
</pre>
</td>
			<td>OVN sample collector set ID shared by controller and agents.</td>
		</tr>
	</tbody>
</table>
<h3>CNI agent configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>agent</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for kube-ovn-cni, the agent responsible for handling CNI requests from the CRI.</td>
		</tr>
		<tr>
			<td>agent.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level agent objects (resources under templates/agent)</td>
		</tr>
		<tr>
			<td>agent.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to kube-ovn-cni pods.</td>
		</tr>
		<tr>
			<td>agent.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level agent objects (resources under templates/agent)</td>
		</tr>
		<tr>
			<td>agent.metrics</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Agent metrics configuration.</td>
		</tr>
		<tr>
			<td>agent.metrics.port</td>
			<td>int</td>
			<td><pre lang="json">
10665
</pre>
</td>
			<td>Configure the port on which the agent service will serve metrics.</td>
		</tr>
		<tr>
			<td>agent.mirroring</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Mirroring of the traffic for debug or analysis. https://kubeovn.github.io/docs/stable/en/guide/mirror/</td>
		</tr>
		<tr>
			<td>agent.mirroring.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable mirroring of the traffic.</td>
		</tr>
		<tr>
			<td>agent.mirroring.interface</td>
			<td>string</td>
			<td><pre lang="json">
"mirror0"
</pre>
</td>
			<td>Interface on which to send the mirrored traffic.</td>
		</tr>
		<tr>
			<td>agent.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to the agent pods (kube-ovn-cni)</td>
		</tr>
		<tr>
			<td>agent.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to the agent pods (kube-ovn-cni)</td>
		</tr>
		<tr>
			<td>agent.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "1000m",
    "ephemeral-storage": "1Gi",
    "memory": "1Gi"
  },
  "requests": {
    "cpu": "100m",
    "memory": "100Mi"
  }
}
</pre>
</td>
			<td>Agent daemon resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>agent.serviceMonitor</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Agent serviceMonitor configuration.</td>
		</tr>
		<tr>
			<td>agent.serviceMonitor.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the deployment of the ServiceMonitor for the agent.</td>
		</tr>
	</tbody>
</table>
<h3>CNI agent configuration.</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>agent.dpdkTunnelInterface</td>
			<td>string</td>
			<td><pre lang="json">
"br-phy"
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>agent.interface</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>""</td>
		</tr>
	</tbody>
</table>
<h3>API Network Attachment Definition configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>apiNad</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>API NetworkAttachmentDefinition to give some pods (CoreDNS, NAT GW) in custom VPCs access to the K8S API. This requires Multus to be installed.</td>
		</tr>
		<tr>
			<td>apiNad.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the creation of the API NAD.</td>
		</tr>
		<tr>
			<td>apiNad.name</td>
			<td>string</td>
			<td><pre lang="json">
"ovn-kubernetes-api"
</pre>
</td>
			<td>Name of the NAD.</td>
		</tr>
		<tr>
			<td>apiNad.provider</td>
			<td>string</td>
			<td><pre lang="json">
"{{ .Values.apiNad.name }}.{{ .Values.namespace }}.ovn"
</pre>
</td>
			<td>Name of the provider, must be in the form "nadName.nadNamespace.ovn".</td>
		</tr>
		<tr>
			<td>apiNad.subnet</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Subnet associated with the NAD, it will have full access to the API server.</td>
		</tr>
		<tr>
			<td>apiNad.subnet.cidrBlock</td>
			<td>string</td>
			<td><pre lang="json">
"100.100.0.0/16,fd00:100:100::/112"
</pre>
</td>
			<td>CIDR block used by the API subnet.</td>
		</tr>
		<tr>
			<td>apiNad.subnet.name</td>
			<td>string</td>
			<td><pre lang="json">
"ovn-kubernetes-api"
</pre>
</td>
			<td>Name of the subnet.</td>
		</tr>
		<tr>
			<td>apiNad.subnet.protocol</td>
			<td>string</td>
			<td><pre lang="json">
"Dual"
</pre>
</td>
			<td>Protocol for the API subnet.</td>
		</tr>
	</tbody>
</table>
<h3>BGP speaker configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>bgpSpeaker</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for kube-ovn-speaker, the BGP speaker announcing routes to the external world.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level kube-ovn-speaker objects (resources under templates/speaker)</td>
		</tr>
		<tr>
			<td>bgpSpeaker.args</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Args passed to the kube-ovn-speaker pod.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the kube-ovn-speaker.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to kube-ovn-speaker pods.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level kube-ovn-speaker objects (resources under templates/speaker)</td>
		</tr>
		<tr>
			<td>bgpSpeaker.nodeSelector</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Node selector to restrict the deployment of the speaker to specific nodes.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to kube-ovn-speaker pods.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to kube-ovn-speaker pods.</td>
		</tr>
		<tr>
			<td>bgpSpeaker.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {},
  "requests": {
    "cpu": "500m",
    "memory": "300Mi"
  }
}
</pre>
</td>
			<td>kube-ovn-speaker resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
	</tbody>
</table>
<h3>OVN-central daemon configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>central</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for ovn-central, the daemon containing the northbound/southbound DBs and northd.</td>
		</tr>
		<tr>
			<td>central.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level ovn-central objects (resources under templates/central)</td>
		</tr>
		<tr>
			<td>central.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to ovn-central pods.</td>
		</tr>
		<tr>
			<td>central.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level ovn-central objects (resources under templates/central)</td>
		</tr>
		<tr>
			<td>central.nodeAffinity</td>
			<td>object</td>
			<td><pre lang="json">
{
  "preferredDuringSchedulingIgnoredDuringExecution": [],
  "requiredDuringSchedulingIgnoredDuringExecution": []
}
</pre>
</td>
			<td>More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity</td>
		</tr>
		<tr>
			<td>central.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to ovn-central pods.</td>
		</tr>
		<tr>
			<td>central.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to ovn-central pods.</td>
		</tr>
		<tr>
			<td>central.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "3",
    "ephemeral-storage": "1Gi",
    "memory": "4Gi"
  },
  "requests": {
    "cpu": "300m",
    "memory": "200Mi"
  }
}
</pre>
</td>
			<td>ovn-central resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>central.tolerations</td>
			<td>list</td>
			<td><pre lang="json">
[
  {
    "effect": "NoSchedule",
    "operator": "Exists"
  },
  {
    "effect": "NoExecute",
    "operator": "Exists"
  },
  {
    "key": "CriticalAddonsOnly",
    "operator": "Exists"
  }
]
</pre>
</td>
			<td>Tolerations for ovn-central pods.</td>
		</tr>
	</tbody>
</table>
<h3>OVN-central daemon configuration.</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>central.ovnLeaderProbeInterval</td>
			<td>int</td>
			<td><pre lang="json">
5
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>central.ovnNorthdNThreads</td>
			<td>int</td>
			<td><pre lang="json">
1
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>central.ovnNorthdProbeInterval</td>
			<td>int</td>
			<td><pre lang="json">
5000
</pre>
</td>
			<td>""</td>
		</tr>
	</tbody>
</table>
<h3>Global parameters</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>clusterDomain</td>
			<td>string</td>
			<td><pre lang="json">
"cluster.local"
</pre>
</td>
			<td>Domain used by the cluster.</td>
		</tr>
		<tr>
			<td>fullnameOverride</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Full name override.</td>
		</tr>
		<tr>
			<td>global</td>
			<td>object</td>
			<td><pre lang="json">
{
  "images": {
    "kubeovn": {
      "repository": "kube-ovn",
      "tag": "v1.16.20"
    }
  },
  "registry": {
    "address": "docker.io/kubeovn",
    "imagePullSecrets": []
  }
}
</pre>
</td>
			<td>Global configuration.</td>
		</tr>
		<tr>
			<td>image</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Image configuration.</td>
		</tr>
		<tr>
			<td>image.pullPolicy</td>
			<td>string</td>
			<td><pre lang="json">
"IfNotPresent"
</pre>
</td>
			<td>Pull policy for all images.</td>
		</tr>
		<tr>
			<td>masterNodes</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Comma-separated list of IPs for each master node. If not specified, fallback to auto-identifying masters based on "masterNodesLabels"</td>
		</tr>
		<tr>
			<td>masterNodesLabels</td>
			<td>object</td>
			<td><pre lang="json">
{
  "kube-ovn/role": "master"
}
</pre>
</td>
			<td>Label used to auto-identify masters. Any node that has any of these labels will be considered a master node. Note: This feature uses Helm "lookup" function, which is not compatible with tools such as ArgoCD.</td>
		</tr>
		<tr>
			<td>nameOverride</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Name override.</td>
		</tr>
		<tr>
			<td>namespace</td>
			<td>string</td>
			<td><pre lang="json">
"kube-system"
</pre>
</td>
			<td>Namespace in which the CNI is deployed.</td>
		</tr>
	</tbody>
</table>
<h3>CNI configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>cni</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>CNI binary/configuration injected on the nodes.</td>
		</tr>
		<tr>
			<td>cni.binaryDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/opt/cni/bin"
</pre>
</td>
			<td>Location on the node where the agent will inject the Kube-OVN binary.</td>
		</tr>
		<tr>
			<td>cni.configDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/etc/cni/net.d"
</pre>
</td>
			<td>Location of the CNI configuration on the node.</td>
		</tr>
		<tr>
			<td>cni.configPriority</td>
			<td>string</td>
			<td><pre lang="json">
"01"
</pre>
</td>
			<td>Priority of Kube-OVN within the CNI configuration directory on the node. Should be a string representing a double-digit integer.</td>
		</tr>
		<tr>
			<td>cni.installCNIPlugins</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Whether to install the bundled CNI plugins besides kube-ovn.</td>
		</tr>
		<tr>
			<td>cni.localConfigFile</td>
			<td>string</td>
			<td><pre lang="json">
"/kube-ovn/01-kube-ovn.conflist"
</pre>
</td>
			<td>Location of the CNI configuration inside the agent's pod.</td>
		</tr>
		<tr>
			<td>cni.mountConfigDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/etc/cni/net.d"
</pre>
</td>
			<td>Location of the CNI configuration to be mounted inside the pod.</td>
		</tr>
		<tr>
			<td>cni.mountToolingDirectory</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Whether to mount the node's tooling directory into the pod.</td>
		</tr>
		<tr>
			<td>cni.nonPrimaryCNI</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Whether to use Kube-OVN as non-primary CNI. When set to true, Kube-OVN will not allocate/handle primary network interfaces. Interfaces are created using Network Attachment Definitions (NADs)</td>
		</tr>
		<tr>
			<td>cni.toolingDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/usr/local/bin"
</pre>
</td>
			<td>Location on the node where the CNI will install Kube-OVN's tooling.</td>
		</tr>
	</tbody>
</table>
<h3>Kube-OVN controller configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>controller</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for kube-ovn-controller, the controller responsible for syncing K8s with OVN.</td>
		</tr>
		<tr>
			<td>controller.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level kube-ovn-controller objects (resources under templates/controller)</td>
		</tr>
		<tr>
			<td>controller.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to kube-ovn-controller pods.</td>
		</tr>
		<tr>
			<td>controller.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level kube-ovn-controller objects (resources under templates/controller)</td>
		</tr>
		<tr>
			<td>controller.leaderElection</td>
			<td>object</td>
			<td><pre lang="json">
{
  "leaseDuration": "",
  "renewDeadline": "",
  "retryPeriod": ""
}
</pre>
</td>
			<td>Leader election timing configuration.</td>
		</tr>
		<tr>
			<td>controller.leaderElection.leaseDuration</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Duration non-leader candidates wait after observing a renewal before attempting to acquire leadership. Empty uses the controller default of 30s.</td>
		</tr>
		<tr>
			<td>controller.leaderElection.renewDeadline</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Duration the acting leader retries refreshing leadership before giving up. Empty uses the controller default of 20s.</td>
		</tr>
		<tr>
			<td>controller.leaderElection.retryPeriod</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Duration leader election clients wait between attempts. Empty uses the controller default of 6s.</td>
		</tr>
		<tr>
			<td>controller.metrics</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Controller metrics configuration.</td>
		</tr>
		<tr>
			<td>controller.metrics.port</td>
			<td>int</td>
			<td><pre lang="json">
10660
</pre>
</td>
			<td>Configure the port on which the controller service will serve metrics.</td>
		</tr>
		<tr>
			<td>controller.nodeAffinity</td>
			<td>object</td>
			<td><pre lang="json">
{
  "preferredDuringSchedulingIgnoredDuringExecution": [],
  "requiredDuringSchedulingIgnoredDuringExecution": []
}
</pre>
</td>
			<td>More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity</td>
		</tr>
		<tr>
			<td>controller.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to kube-ovn-controller pods.</td>
		</tr>
		<tr>
			<td>controller.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to kube-ovn-controller pods.</td>
		</tr>
		<tr>
			<td>controller.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "1000m",
    "ephemeral-storage": "1Gi",
    "memory": "1Gi"
  },
  "requests": {
    "cpu": "200m",
    "memory": "200Mi"
  }
}
</pre>
</td>
			<td>kube-ovn-controller resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>controller.serviceMonitor</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Controller serviceMonitor configuration.</td>
		</tr>
		<tr>
			<td>controller.serviceMonitor.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the deployment of the ServiceMonitor for the Kube-OVN controller.</td>
		</tr>
		<tr>
			<td>controller.tolerations</td>
			<td>list</td>
			<td><pre lang="json">
[
  {
    "effect": "NoSchedule",
    "operator": "Exists"
  },
  {
    "key": "CriticalAddonsOnly",
    "operator": "Exists"
  }
]
</pre>
</td>
			<td>Tolerations for kube-ovn-controller pods.</td>
		</tr>
	</tbody>
</table>
<h3>Extra objects</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>extraObjects</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Array of extra K8s manifests to deploy. Note: Supports use of custom Helm templates (Go templating)</td>
		</tr>
	</tbody>
</table>
<h3>Opt-in/out Features</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>features</td>
			<td>object</td>
			<td><pre lang="json">
{
  "ENABLE_ANP": false,
  "ENABLE_BIND_LOCAL_IP": true,
  "ENABLE_DNS_NAME_RESOLVER": false,
  "ENABLE_OVN_LB_PREFER_LOCAL": false,
  "LS_CT_SKIP_DST_LPORT_IPS": true,
  "LS_DNAT_MOD_DL_DST": true,
  "OVSDB_CON_TIMEOUT": 3,
  "OVSDB_INACTIVITY_TIMEOUT": 10,
  "SET_GENEVE_TX_OFF": true,
  "SET_VXLAN_TX_OFF": false,
  "enableExternalVpcs": false,
  "enableHardwareOffload": false,
  "enableKeepVmIps": true,
  "enableLiveMigrationOptimization": true,
  "enableLoadbalancer": true,
  "enableLoadbalancerService": false,
  "enableNatGateways": true,
  "enableNetworkPolicies": true,
  "enableOvnInterconnections": false,
  "enableOvnIpsec": false,
  "enableRecompute": true,
  "enableSecureServing": false,
  "enableTproxy": false,
  "enableU2OInterconnections": false
}
</pre>
</td>
			<td>Features of Kube-OVN we wish to enable/disable.</td>
		</tr>
		<tr>
			<td>features.enableExternalVpcs</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable external VPCs</td>
		</tr>
		<tr>
			<td>features.enableHardwareOffload</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable hardware offloads</td>
		</tr>
		<tr>
			<td>features.enableKeepVmIps</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable persistent VM IPs</td>
		</tr>
		<tr>
			<td>features.enableLiveMigrationOptimization</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable optimized live migrations for VMs</td>
		</tr>
		<tr>
			<td>features.enableLoadbalancer</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable Kube-OVN loadbalancers</td>
		</tr>
		<tr>
			<td>features.enableLoadbalancerService</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable Kube-OVN loadbalancer services</td>
		</tr>
		<tr>
			<td>features.enableNatGateways</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable NAT gateways</td>
		</tr>
		<tr>
			<td>features.enableNetworkPolicies</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable Kube-OVN network policies</td>
		</tr>
		<tr>
			<td>features.enableOvnInterconnections</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable OVN interconnections</td>
		</tr>
		<tr>
			<td>features.enableOvnIpsec</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable IPSEC</td>
		</tr>
		<tr>
			<td>features.enableRecompute</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable periodic ovn-controller recompute</td>
		</tr>
		<tr>
			<td>features.enableSecureServing</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable secure serving</td>
		</tr>
		<tr>
			<td>features.enableTproxy</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable TProxy</td>
		</tr>
		<tr>
			<td>features.enableU2OInterconnections</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable underlay to overlay interconnections</td>
		</tr>
	</tbody>
</table>
<h3>OVN IC controller configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>ic</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for the OVN interconnection (IC) controller.</td>
		</tr>
		<tr>
			<td>ic.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to ovn-ic-controller pods.</td>
		</tr>
		<tr>
			<td>ic.nodeAffinity</td>
			<td>object</td>
			<td><pre lang="json">
{
  "preferredDuringSchedulingIgnoredDuringExecution": [],
  "requiredDuringSchedulingIgnoredDuringExecution": []
}
</pre>
</td>
			<td>More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity</td>
		</tr>
		<tr>
			<td>ic.tolerations</td>
			<td>list</td>
			<td><pre lang="json">
[
  {
    "effect": "NoSchedule",
    "operator": "Exists"
  },
  {
    "effect": "NoExecute",
    "operator": "Exists"
  },
  {
    "key": "CriticalAddonsOnly",
    "operator": "Exists"
  }
]
</pre>
</td>
			<td>Tolerations for ovn-ic-controller pods.</td>
		</tr>
	</tbody>
</table>
<h3>Kubelet configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>kubelet</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Kubelet configuration.</td>
		</tr>
		<tr>
			<td>kubelet.directory</td>
			<td>string</td>
			<td><pre lang="json">
"/var/lib/kubelet"
</pre>
</td>
			<td>Directory in which the kubelet operates.</td>
		</tr>
		<tr>
			<td>logging.directory</td>
			<td>string</td>
			<td><pre lang="json">
"/var/log"
</pre>
</td>
			<td>Directory in which to write the logs.</td>
		</tr>
	</tbody>
</table>
<h3>Logging configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>logging</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Logging configuration for all the daemons.</td>
		</tr>
	</tbody>
</table>
<h3>OVN monitoring daemon configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>monitor</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for kube-ovn-monitor, the agent monitoring and returning metrics for the northbound/southbound DBs and northd.</td>
		</tr>
		<tr>
			<td>monitor.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level kube-ovn-monitor objects (resources under templates/monitor)</td>
		</tr>
		<tr>
			<td>monitor.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to kube-ovn-monitor pods.</td>
		</tr>
		<tr>
			<td>monitor.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level kube-ovn-monitor objects (resources under templates/monitor)</td>
		</tr>
		<tr>
			<td>monitor.metrics</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>kube-ovn-monitor metrics configuration.</td>
		</tr>
		<tr>
			<td>monitor.metrics.port</td>
			<td>int</td>
			<td><pre lang="json">
10661
</pre>
</td>
			<td>Configure the port on which the kube-ovn-monitor service will serve metrics.</td>
		</tr>
		<tr>
			<td>monitor.nodeAffinity</td>
			<td>object</td>
			<td><pre lang="json">
{
  "preferredDuringSchedulingIgnoredDuringExecution": [],
  "requiredDuringSchedulingIgnoredDuringExecution": []
}
</pre>
</td>
			<td>More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity</td>
		</tr>
		<tr>
			<td>monitor.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to kube-ovn-monitor pods.</td>
		</tr>
		<tr>
			<td>monitor.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to kube-ovn-monitor pods.</td>
		</tr>
		<tr>
			<td>monitor.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "200m",
    "ephemeral-storage": "1Gi",
    "memory": "200Mi"
  },
  "requests": {
    "cpu": "200m",
    "memory": "200Mi"
  }
}
</pre>
</td>
			<td>kube-ovn-monitor resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>monitor.serviceMonitor</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>kube-ovn-monitor serviceMonitor configuration.</td>
		</tr>
		<tr>
			<td>monitor.serviceMonitor.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the deployment of the ServiceMonitor for the kube-ovn-monitor.</td>
		</tr>
		<tr>
			<td>monitor.tolerations</td>
			<td>list</td>
			<td><pre lang="json">
[
  {
    "effect": "NoSchedule",
    "operator": "Exists"
  },
  {
    "key": "CriticalAddonsOnly",
    "operator": "Exists"
  }
]
</pre>
</td>
			<td>Tolerations for kube-ovn-monitor pods.</td>
		</tr>
	</tbody>
</table>
<h3>NAT gateways configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>natGw</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for the NAT gateways.</td>
		</tr>
		<tr>
			<td>natGw.bgpSpeaker</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration of the BGP sidecar for when a NAT gateway is running in BGP mode.</td>
		</tr>
		<tr>
			<td>natGw.bgpSpeaker.apiNadProvider</td>
			<td>string</td>
			<td><pre lang="json">
"{{ .Values.apiNad.name }}.{{ .Values.namespace }}.ovn"
</pre>
</td>
			<td>Network attachment definition used to reach the API server when running on BGP mode. By default, equals the value set at ".apiNad.provider", you will need to set ".apiNad.enabled" to true. See https://kubeovn.github.io/docs/stable/en/advance/with-bgp/</td>
		</tr>
		<tr>
			<td>natGw.bgpSpeaker.image</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Image used by the NAT gateway sidecar.</td>
		</tr>
		<tr>
			<td>natGw.bgpSpeaker.image.pullPolicy</td>
			<td>string</td>
			<td><pre lang="json">
"IfNotPresent"
</pre>
</td>
			<td>Image pull policy.</td>
		</tr>
		<tr>
			<td>natGw.bgpSpeaker.image.repository</td>
			<td>string</td>
			<td><pre lang="json">
"docker.io/kubeovn/kube-ovn"
</pre>
</td>
			<td>Image repository.</td>
		</tr>
		<tr>
			<td>natGw.bgpSpeaker.image.tag</td>
			<td>string</td>
			<td><pre lang="json">
"v1.16.20"
</pre>
</td>
			<td>Image tag.</td>
		</tr>
		<tr>
			<td>natGw.image</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Image used by the NAT gateway.</td>
		</tr>
		<tr>
			<td>natGw.image.pullPolicy</td>
			<td>string</td>
			<td><pre lang="json">
"IfNotPresent"
</pre>
</td>
			<td>Image pull policy.</td>
		</tr>
		<tr>
			<td>natGw.image.repository</td>
			<td>string</td>
			<td><pre lang="json">
"docker.io/kubeovn/vpc-nat-gateway"
</pre>
</td>
			<td>Image repository.</td>
		</tr>
		<tr>
			<td>natGw.image.tag</td>
			<td>string</td>
			<td><pre lang="json">
"v1.16.20"
</pre>
</td>
			<td>Image tag.</td>
		</tr>
		<tr>
			<td>natGw.namePrefix</td>
			<td>string</td>
			<td><pre lang="json">
"vpc-nat-gw"
</pre>
</td>
			<td>Prefix appended to the name of the NAT gateways when generating the Pods. If this value is changed after NAT GWs have been provisioned, every NAT gateway will need to be manually destroyed and recreated.</td>
		</tr>
	</tbody>
</table>
<h3>Network Policies</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>networkPolicies</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for network policies</td>
		</tr>
		<tr>
			<td>networkPolicies.enforcement</td>
			<td>string</td>
			<td><pre lang="json">
"standard"
</pre>
</td>
			<td>Enforcement level of network policies when they get applied (can be: standard, lax). Enforcement "standard" blocks everything except what is allowed by the network policies. Enforcement "lax" is similar to "standard" with the exception that ARP/DHCPv4/DHCPv6/ICMPv4/ICMPv6 is allowed by default. This mode is useful when using Kubevirt and VMs with IPs configured via Kube-OVN's DHCP.</td>
		</tr>
	</tbody>
</table>
<h3>Network parameters of the CNI</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>networking</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>General configuration of the network created by Kube-OVN.</td>
		</tr>
		<tr>
			<td>networking.defaultVpcName</td>
			<td>string</td>
			<td><pre lang="json">
"ovn-cluster"
</pre>
</td>
			<td>Name of the default VPC once it is generated in the cluster. Pods in the default subnet live in this VPC.</td>
		</tr>
		<tr>
			<td>networking.enableCompact</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>networking.enableEcmp</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>networking.enableEipSnat</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable EIP and SNAT.</td>
		</tr>
		<tr>
			<td>networking.enableMetrics</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable listening on the metrics endpoint for the CNI daemons.</td>
		</tr>
		<tr>
			<td>networking.enableSsl</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Deploy the CNI with SSL encryption in between components.</td>
		</tr>
		<tr>
			<td>networking.exchangeLinkName</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>networking.excludeIps</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>IPs to exclude from IPAM in the default subnet.</td>
		</tr>
		<tr>
			<td>networking.externalGatewayConfigNs</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Namespace where ovn-external-gw-config ConfigMap is located. Empty means it will use the same namespace as the controller (PodNamespace).</td>
		</tr>
		<tr>
			<td>networking.join</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration of the "join" subnet, used by the nodes to contact (join) the pods in the default subnet. If .networking.stack is set to IPv4, only the .v4 key is used. If .networking.stack is set to IPv6, only the .v6 key is used. If .networking.stack is set to Dual, both keys are used.</td>
		</tr>
		<tr>
			<td>networking.join.cidr</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>CIDR used by the join subnet.</td>
		</tr>
		<tr>
			<td>networking.join.cidr.v4</td>
			<td>string</td>
			<td><pre lang="json">
"100.64.0.0/16"
</pre>
</td>
			<td>IPv4 CIDR.</td>
		</tr>
		<tr>
			<td>networking.join.cidr.v6</td>
			<td>string</td>
			<td><pre lang="json">
"fd00:100:64::/112"
</pre>
</td>
			<td>IPv6 CIDR.</td>
		</tr>
		<tr>
			<td>networking.join.subnetName</td>
			<td>string</td>
			<td><pre lang="json">
"join"
</pre>
</td>
			<td>Name of the join subnet once it gets generated in the cluster.</td>
		</tr>
		<tr>
			<td>networking.networkType</td>
			<td>string</td>
			<td><pre lang="json">
"geneve"
</pre>
</td>
			<td>Network type can be "geneve" or "vlan".</td>
		</tr>
		<tr>
			<td>networking.nodeLocalDnsIp</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Comma-separated string of NodeLocal DNS IP addresses.</td>
		</tr>
		<tr>
			<td>networking.podNicType</td>
			<td>string</td>
			<td><pre lang="json">
"veth-pair"
</pre>
</td>
			<td>NIC type used on pods to connect them to the CNI.</td>
		</tr>
		<tr>
			<td>networking.pods</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for the default pod subnet. If .networking.stack is set to IPv4, only the .v4 key is used. If .networking.stack is set to IPv6, only the .v6 key is used. If .networking.stack is set to Dual, both keys are used.</td>
		</tr>
		<tr>
			<td>networking.pods.cidr</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>CIDR used by the pods subnet.</td>
		</tr>
		<tr>
			<td>networking.pods.cidr.v4</td>
			<td>string</td>
			<td><pre lang="json">
"10.16.0.0/16"
</pre>
</td>
			<td>IPv4 CIDR.</td>
		</tr>
		<tr>
			<td>networking.pods.cidr.v6</td>
			<td>string</td>
			<td><pre lang="json">
"fd00:10:16::/112"
</pre>
</td>
			<td>IPv6 CIDR.</td>
		</tr>
		<tr>
			<td>networking.pods.enableGatewayChecks</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Enable default gateway checks.</td>
		</tr>
		<tr>
			<td>networking.pods.enableLogicalGateways</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable logical gateways.</td>
		</tr>
		<tr>
			<td>networking.pods.gateways</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Gateways used in the pod subnet.</td>
		</tr>
		<tr>
			<td>networking.pods.gateways.v4</td>
			<td>string</td>
			<td><pre lang="json">
"10.16.0.1"
</pre>
</td>
			<td>IPv4 gateway.</td>
		</tr>
		<tr>
			<td>networking.pods.gateways.v6</td>
			<td>string</td>
			<td><pre lang="json">
"fd00:10:16::1"
</pre>
</td>
			<td>IPv6 gateway.</td>
		</tr>
		<tr>
			<td>networking.pods.mtu</td>
			<td>int</td>
			<td><pre lang="json">
0
</pre>
</td>
			<td>MTU of the subnet. If set to 0, the MTU is auto-detected.</td>
		</tr>
		<tr>
			<td>networking.pods.subnetName</td>
			<td>string</td>
			<td><pre lang="json">
"ovn-default"
</pre>
</td>
			<td>Name of the pod subnet once it gets generated in the cluster.</td>
		</tr>
		<tr>
			<td>networking.services</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for the service subnet. If .networking.stack is set to IPv4, only the .v4 key is used. If .networking.stack is set to IPv6, only the .v6 key is used. If .networking.stack is set to Dual, both keys are used.</td>
		</tr>
		<tr>
			<td>networking.services.cidr</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>CIDR used by the service subnet.</td>
		</tr>
		<tr>
			<td>networking.services.cidr.v4</td>
			<td>string</td>
			<td><pre lang="json">
"10.96.0.0/12"
</pre>
</td>
			<td>IPv4 CIDR.</td>
		</tr>
		<tr>
			<td>networking.services.cidr.v6</td>
			<td>string</td>
			<td><pre lang="json">
"fd00:10:96::/112"
</pre>
</td>
			<td>IPv6 CIDR.</td>
		</tr>
		<tr>
			<td>networking.skipConntrackDstCidrs</td>
			<td>string</td>
			<td><pre lang="json">
""
</pre>
</td>
			<td>Comma-separated list of destination IP CIDRs that should skip conntrack processing.</td>
		</tr>
		<tr>
			<td>networking.stack</td>
			<td>string</td>
			<td><pre lang="json">
"IPv4"
</pre>
</td>
			<td>Protocol(s) used by Kube-OVN to allocate IPs to pods and services. Can be either IPv4, IPv6 or Dual.</td>
		</tr>
		<tr>
			<td>networking.tunnelType</td>
			<td>string</td>
			<td><pre lang="json">
"geneve"
</pre>
</td>
			<td>Tunnel type can be "geneve", "vxlan" or "stt".</td>
		</tr>
		<tr>
			<td>networking.vlan</td>
			<td>object</td>
			<td><pre lang="json">
{
  "id": "100",
  "interfaceName": "",
  "name": "ovn-vlan",
  "providerName": "provider"
}
</pre>
</td>
			<td>Configuration if we're running on top of a VLAN.</td>
		</tr>
	</tbody>
</table>
<h3>OVS/OVN daemons configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>ovsOvn</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for ovs-ovn, the Open vSwitch/Open Virtual Network daemons.</td>
		</tr>
		<tr>
			<td>ovsOvn.affinity</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Affinity for ovs-ovn pods.</td>
		</tr>
		<tr>
			<td>ovsOvn.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level ovs-ovn objects (resources under templates/ovs-ovn)</td>
		</tr>
		<tr>
			<td>ovsOvn.disableModulesManagement</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Disable auto-loading of kernel modules by OVS. If this is disabled, you will have to enable the Open vSwitch kernel module yourself.</td>
		</tr>
		<tr>
			<td>ovsOvn.dpdkHybrid</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>DPDK-hybrid support for OVS. ref: https://kubeovn.github.io/docs/v1.12.x/en/advance/dpdk/</td>
		</tr>
		<tr>
			<td>ovsOvn.dpdkHybrid.affinity</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Affinity for the ovs-ovn-dpdk DaemonSet.</td>
		</tr>
		<tr>
			<td>ovsOvn.dpdkHybrid.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enables DPDK-hybrid support on OVS.</td>
		</tr>
		<tr>
			<td>ovsOvn.dpdkHybrid.nodeSelector</td>
			<td>object</td>
			<td><pre lang="json">
{
  "kubernetes.io/os": "linux",
  "ovn.kubernetes.io/ovs_dp_type": "userspace"
}
</pre>
</td>
			<td>Node selector to restrict the deployment of DPDK-hybrid OVS to specific nodes.</td>
		</tr>
		<tr>
			<td>ovsOvn.dpdkHybrid.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "2",
    "ephemeral-storage": "1Gi",
    "hugepages-2Mi": "1Gi",
    "memory": "1000Mi"
  },
  "requests": {
    "cpu": "200m",
    "memory": "200Mi"
  }
}
</pre>
</td>
			<td>ovs-ovn resource limits & requests when DPDK-hybrid is enabled. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>ovsOvn.dpdkHybrid.tag</td>
			<td>string</td>
			<td><pre lang="json">
"v1.16.20-dpdk"
</pre>
</td>
			<td>DPDK image tag.</td>
		</tr>
		<tr>
			<td>ovsOvn.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to ovs-ovn pods.</td>
		</tr>
		<tr>
			<td>ovsOvn.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level ovs-ovn objects (resources under templates/ovs-ovn)</td>
		</tr>
		<tr>
			<td>ovsOvn.nodeSelector</td>
			<td>object</td>
			<td><pre lang="json">
{
  "kubernetes.io/os": "linux"
}
</pre>
</td>
			<td>Node selector to restrict the deployment of ovs-ovn to specific nodes.</td>
		</tr>
		<tr>
			<td>ovsOvn.ovnDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/etc/origin/ovn"
</pre>
</td>
			<td>Directory on the node where Open Virtual Network (OVN) lives.</td>
		</tr>
		<tr>
			<td>ovsOvn.ovsDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/etc/origin/openvswitch"
</pre>
</td>
			<td>Directory on the node where Open vSwitch (OVS) lives.</td>
		</tr>
		<tr>
			<td>ovsOvn.ovsIpsecKeysDirectory</td>
			<td>string</td>
			<td><pre lang="json">
"/etc/origin/ovs_ipsec_keys"
</pre>
</td>
			<td>Directory on the node where Open vSwitch (OVS) IPSEC keys live.</td>
		</tr>
		<tr>
			<td>ovsOvn.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to ovs-ovn pods.</td>
		</tr>
		<tr>
			<td>ovsOvn.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to ovs-ovn pods.</td>
		</tr>
		<tr>
			<td>ovsOvn.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "2",
    "ephemeral-storage": "1Gi",
    "memory": "1000Mi"
  },
  "requests": {
    "cpu": "200m",
    "memory": "200Mi"
  }
}
</pre>
</td>
			<td>ovs-ovn resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>ovsOvn.updateStrategy</td>
			<td>object</td>
			<td><pre lang="json">
{
  "maxSurge": 1,
  "maxUnavailable": 0,
  "type": "RollingUpdate"
}
</pre>
</td>
			<td>ovs-ovn DaemonSet update strategy. ref: https://kubernetes.io/docs/tasks/manage-daemon/update-daemon-set/#daemonset-update-strategy</td>
		</tr>
		<tr>
			<td>ovsOvn.upgrade</td>
			<td>object</td>
			<td><pre lang="json">
{
  "enabled": true
}
</pre>
</td>
			<td>Upgrade logic for OVS/OVN.</td>
		</tr>
	</tbody>
</table>
<h3>Performance configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>performance</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Performance tuning parameters.</td>
		</tr>
		<tr>
			<td>performance.gcInterval</td>
			<td>int</td>
			<td><pre lang="json">
360
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>performance.inspectInterval</td>
			<td>int</td>
			<td><pre lang="json">
20
</pre>
</td>
			<td>""</td>
		</tr>
		<tr>
			<td>performance.ovsVsctlConcurrency</td>
			<td>int</td>
			<td><pre lang="json">
100
</pre>
</td>
			<td>""</td>
		</tr>
	</tbody>
</table>
<h3>Ping daemon configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>pinger</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration for kube-ovn-pinger, the agent monitoring and returning metrics for OVS/external connectivity.</td>
		</tr>
		<tr>
			<td>pinger.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level kube-ovn-pinger objects (resources under templates/pinger)</td>
		</tr>
		<tr>
			<td>pinger.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to kube-ovn-pinger pods.</td>
		</tr>
		<tr>
			<td>pinger.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level kube-ovn-pinger objects (resources under templates/pinger)</td>
		</tr>
		<tr>
			<td>pinger.metrics</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>kube-ovn-pinger metrics configuration.</td>
		</tr>
		<tr>
			<td>pinger.metrics.port</td>
			<td>int</td>
			<td><pre lang="json">
8080
</pre>
</td>
			<td>Configure the port on which the kube-ovn-monitor service will serve metrics.</td>
		</tr>
		<tr>
			<td>pinger.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to kube-ovn-pinger pods.</td>
		</tr>
		<tr>
			<td>pinger.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to kube-ovn-pinger pods.</td>
		</tr>
		<tr>
			<td>pinger.resources</td>
			<td>object</td>
			<td><pre lang="json">
{
  "limits": {
    "cpu": "200m",
    "ephemeral-storage": "1Gi",
    "memory": "400Mi"
  },
  "requests": {
    "cpu": "100m",
    "memory": "100Mi"
  }
}
</pre>
</td>
			<td>kube-ovn-pinger resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/</td>
		</tr>
		<tr>
			<td>pinger.serviceMonitor</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Ping daemon serviceMonitor configuration.</td>
		</tr>
		<tr>
			<td>pinger.serviceMonitor.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the deployment of the ServiceMonitor for the pinger.</td>
		</tr>
		<tr>
			<td>pinger.targets</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Remote targets used by the pinger daemon to determine if the CNI works and has external connectivity.</td>
		</tr>
		<tr>
			<td>pinger.targets.externalAddresses</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Raw IPv4/6 on which to issue pings.</td>
		</tr>
		<tr>
			<td>pinger.targets.externalAddresses.v4</td>
			<td>string</td>
			<td><pre lang="json">
"1.1.1.1"
</pre>
</td>
			<td>IPv4 address.</td>
		</tr>
		<tr>
			<td>pinger.targets.externalAddresses.v6</td>
			<td>string</td>
			<td><pre lang="json">
"2606:4700:4700::1111"
</pre>
</td>
			<td>IPv6 address.</td>
		</tr>
		<tr>
			<td>pinger.targets.externalDomain</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Domains to resolve and to ping. Make sure the v6 domain resolves both A and AAAA records, while the v4 only resolves A records.</td>
		</tr>
		<tr>
			<td>pinger.targets.externalDomain.v4</td>
			<td>string</td>
			<td><pre lang="json">
"kube-ovn.io."
</pre>
</td>
			<td>Domain name resolving to an IPv4 only (A record)</td>
		</tr>
		<tr>
			<td>pinger.targets.externalDomain.v6</td>
			<td>string</td>
			<td><pre lang="json">
"google.com."
</pre>
</td>
			<td>Domain name resolving to an IPv6 and IPv4 only (A/AAAA record)</td>
		</tr>
	</tbody>
</table>
<h3>Validating webhook configuration</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
		<tr>
			<td>validatingWebhook</td>
			<td>object</td>
			<td><pre lang="">
"{}"
</pre>
</td>
			<td>Configuration of the validating webhook used to verify custom resources before they are pushed to Kubernetes. Make sure cert-manager is installed for the generation of certificates for the webhook. See https://kubeovn.github.io/docs/stable/en/guide/webhook/</td>
		</tr>
		<tr>
			<td>validatingWebhook.annotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to all top-level kube-ovn-webhook objects (resources under templates/webhook)</td>
		</tr>
		<tr>
			<td>validatingWebhook.certificate.create</td>
			<td>bool</td>
			<td><pre lang="json">
true
</pre>
</td>
			<td>Create the webhook Certificate and self-signed Issuer. Set to false to manage your own cert-manager Certificate and issuer outside this chart; the webhook remains enabled. See the README for required resource names and upgrade considerations.</td>
		</tr>
		<tr>
			<td>validatingWebhook.enabled</td>
			<td>bool</td>
			<td><pre lang="json">
false
</pre>
</td>
			<td>Enable the deployment of the validating webhook.</td>
		</tr>
		<tr>
			<td>validatingWebhook.extraEnv</td>
			<td>list</td>
			<td><pre lang="json">
[]
</pre>
</td>
			<td>Extra environment variables to be added to kube-ovn-webhook pods.</td>
		</tr>
		<tr>
			<td>validatingWebhook.labels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to all top-level kube-ovn-webhook objects (resources under templates/webhook)</td>
		</tr>
		<tr>
			<td>validatingWebhook.podAnnotations</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Annotations to be added to kube-ovn-webhook pods.</td>
		</tr>
		<tr>
			<td>validatingWebhook.podLabels</td>
			<td>object</td>
			<td><pre lang="json">
{}
</pre>
</td>
			<td>Labels to be added to kube-ovn-webhook pods.</td>
		</tr>
		<tr>
			<td>validatingWebhook.tolerations</td>
			<td>list</td>
			<td><pre lang="json">
[
  {
    "effect": "NoSchedule",
    "operator": "Exists"
  }
]
</pre>
</td>
			<td>Tolerations for kube-ovn-webhook pods.</td>
		</tr>
	</tbody>
</table>

<h3>Other Values</h3>
<table>
	<thead>
		<th>Key</th>
		<th>Type</th>
		<th>Default</th>
		<th>Description</th>
	</thead>
	<tbody>
	<tr>
		<td>central.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>central.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>controller.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>controller.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>ic.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>ic.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>monitor.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>monitor.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution</td>
		<td>list</td>
		<td><pre lang="json">
[]
</pre>
</td>
		<td>- antarctica-west1</td>
	</tr>
	<tr>
		<td>ovsOvn.upgrade.enabled</td>
		<td>bool</td>
		<td><pre lang="json">
true
</pre>
</td>
		<td>Enable post-upgrade hooks to run upgrade logic of OVS/OVN.</td>
	</tr>
	</tbody>
</table>
